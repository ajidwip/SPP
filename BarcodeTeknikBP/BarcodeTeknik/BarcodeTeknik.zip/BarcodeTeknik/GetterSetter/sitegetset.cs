﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class sitegetset
    {
        public string Site { get; set; }

        public string Deskripsi { get; set; }
    }
}