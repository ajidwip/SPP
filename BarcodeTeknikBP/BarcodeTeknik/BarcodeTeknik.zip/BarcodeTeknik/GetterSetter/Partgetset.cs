﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class Partgetset
    {
        public string PartNo { get; set; }
        public string Site { get; set; }

        public string AccountingGroup { get; set; }
        public string PartProductCode { get; set; }

        public string PartProductFamily { get; set; }

        public string PrimeCommodity { get; set; }

        public string Unit { get; set; }

        public string PartDescription { get; set; }

        public string RakNo { get; set; }

        public string Barcode { get; set; }

        public string qty { get; set; }
    }
}