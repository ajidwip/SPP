﻿namespace BarcodeTeknik
{
}

namespace BarcodeTeknik
{
}