﻿Selectize.define('no-delete', function(options) {
  this.deleteSelection = function() {};
});