﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class wowithoutpartgetset
    {
        public string WoNo { get; set; }
        public string Deksripsi { get; set; }

        public string Contract { get; set; }
    }
}