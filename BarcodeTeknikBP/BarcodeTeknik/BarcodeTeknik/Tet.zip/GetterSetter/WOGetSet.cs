﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class WOGetSet
    {
        public string WO { get; set; }

        public string DeskripsiWO { get; set; }

        public string Penyebab { get; set; }

        public string Solusi { get; set; }

        public string SolusiDetail { get; set; }

        public string Status { get; set; }
        public string Contract { get; set; }

        public string NIK { get; set; }

        public string Class { get; set; }

        public string Cause { get; set; }

        public string PerfomedAction { get; set; }

        public string Type { get; set; }
    }
}