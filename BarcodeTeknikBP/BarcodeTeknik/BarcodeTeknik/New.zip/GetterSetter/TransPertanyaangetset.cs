﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class TransPertanyaangetset
    {
        public int id_pertanyaanumur { get; set; }
        public int id_pertanyaanestimasi { get; set; }
        public int id_pertanyaanfungsi { get; set; }
        public string accounting_group { get; set; }
    
    }
}