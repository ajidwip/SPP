﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class PurchaseGroupgetset
    {
        public string PurchaseGroupId { get; set; }
        public string PurchaseGroupDesc { get; set; }
        public string AcctGroup { get; set; }
        public string status { get; set; }

    }
}