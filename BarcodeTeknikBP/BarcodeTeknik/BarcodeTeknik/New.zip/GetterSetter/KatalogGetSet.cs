﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BarcodeTeknik.GetterSetter
{
    public class KatalogGetSet
    {
        public string PartNo { get; set; }
    
    
        public string Description { get; set; }
        public string image { get; set; }
        public string image2 { get; set; }

        public string image3 { get; set; }
    }
}